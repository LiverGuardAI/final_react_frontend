declare module 'dcmjs';
