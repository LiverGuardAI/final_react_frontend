declare module '@kitware/vtk.js/Filters/General/ImageMarchingCubes' {
  const content: any;
  export default content;
}

declare module '@kitware/vtk.js/*' {
  const content: any;
  export = content;
}
